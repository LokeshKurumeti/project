package com.bill.billpayment.service;

import com.bill.billpayment.entities.Dthgpay;

public interface Telegpayservice {
	public boolean verify(Dthgpay gpay);
	public boolean dstatus(String telephonenumber);
}
