package com.bill.billpayment.service;

import com.bill.billpayment.entities.electricity;

public interface ebillservice
{
public int savebill(electricity electricity);
}
