package com.bill.billpayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillpaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillpaymentApplication.class, args);
	}

}
