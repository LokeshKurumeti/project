package com.bill.billpayment.dao;

import org.springframework.data.repository.CrudRepository;

import com.bill.billpayment.entities.Dthgpay;

public interface Dthgpaydao extends CrudRepository<Dthgpay,String>{

}
