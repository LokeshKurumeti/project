package com.bill.billpayment.entities;

public class Telegpay {

}
