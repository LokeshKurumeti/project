package com.bill.billpayment.service;

import com.bill.billpayment.entities.Dthgpay;


public interface Dthgpayservice {
	public boolean verify(Dthgpay gpay);
	public boolean dstatus(String billnumber);
}
