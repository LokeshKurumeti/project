package com.bill.billpayment.service;


import com.bill.billpayment.entities.Dthcredit;

public interface Dthcreditservice {
	public boolean verify(Dthcredit credit);
	public boolean dthstatus(String servicenumber);

}
