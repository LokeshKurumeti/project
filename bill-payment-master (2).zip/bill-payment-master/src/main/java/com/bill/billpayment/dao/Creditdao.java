package com.bill.billpayment.dao;

import org.springframework.data.repository.CrudRepository;

import com.bill.billpayment.entities.Credit;

public interface Creditdao extends CrudRepository<Credit, String>
{

}
