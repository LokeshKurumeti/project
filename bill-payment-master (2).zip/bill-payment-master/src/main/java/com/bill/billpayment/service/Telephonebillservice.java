package com.bill.billpayment.service;

import com.bill.billpayment.entities.Dth;
import com.bill.billpayment.entities.telephone;

public interface Telephonebillservice {
	public int savebill(telephone phone);
}
