package com.bill.billpayment.service;

import java.util.List;

import com.bill.billpayment.entities.Aminlogin;
import com.bill.billpayment.entities.Dth;
import com.bill.billpayment.entities.Help;
import com.bill.billpayment.entities.Vendor;
import com.bill.billpayment.entities.electricity;
import com.bill.billpayment.entities.telephone;

public interface Adminservice 
{
public boolean login(Aminlogin adminlogin);
public List<Vendor> getallvendors();
public boolean activate(String username);
public boolean deactivate(String username);
public List<electricity> getelectricbills();
public List<Dth> getdthbills();
List<Help> getallhelpList();
public List<telephone> getTelephonebills();
}
