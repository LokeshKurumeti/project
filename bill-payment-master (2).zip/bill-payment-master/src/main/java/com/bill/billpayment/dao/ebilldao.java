package com.bill.billpayment.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.bill.billpayment.entities.Dth;
import com.bill.billpayment.entities.electricity;

public interface ebilldao extends CrudRepository<electricity, Integer>
{

	electricity findByBillnumber(String billnumber);
	public List<electricity> findAll();
   
}
