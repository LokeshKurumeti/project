package com.bill.billpayment.service;


import com.bill.billpayment.entities.Credit;


public interface Creditservice
{
	public boolean verify(Credit credit);
	public boolean status(String billnumber);
	}
