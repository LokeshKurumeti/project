package com.bill.billpayment.service;



import com.bill.billpayment.entities.Recordbills;

public interface Recordbillsservice
{
public int savebills(Recordbills recordbill);


}
