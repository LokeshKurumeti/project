package com.bill.billpayment.service;

import com.bill.billpayment.entities.Dth;

public interface Dthbillservice 
{
public int savebill(Dth dth);
}
