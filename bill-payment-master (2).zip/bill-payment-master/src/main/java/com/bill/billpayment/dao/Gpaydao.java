package com.bill.billpayment.dao;

import org.springframework.data.repository.CrudRepository;

import com.bill.billpayment.entities.Gpay;

public interface Gpaydao extends CrudRepository<Gpay,String>{

	

}
