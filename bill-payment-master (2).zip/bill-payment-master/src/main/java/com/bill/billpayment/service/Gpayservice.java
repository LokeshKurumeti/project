package com.bill.billpayment.service;


import com.bill.billpayment.entities.Gpay;

public interface Gpayservice 
{
	public boolean verify(Gpay gpay);
	public boolean status(String billnumber);
	
}
